package com.example.retrofit_with_recyclerview
// to represent the JSON response:
data class Post(
    val title: String,
    val body: String
)
























/*  his code declares a data class named Post with two properties: title and body. The data keyword is used to declare a class that is primarily used to hold data. In this case, it represents a single post with a title and body.

val title: String declares a read-only property title of type String that represents the title of the post.

val body: String declares a read-only property body of type String that represents the body or content of the post.

The Post data class is a simple representation of the JSON response structure that will be used to map the JSON data received from the API to Kotlin objects.  */