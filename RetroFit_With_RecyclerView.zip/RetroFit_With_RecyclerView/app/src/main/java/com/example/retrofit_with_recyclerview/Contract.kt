package com.example.retrofit_with_recyclerview

interface Contract {
    interface View {
        fun showPosts(posts: List<Post>)
        fun showError(message: String)
        
    }

    interface Model {
        
    }

    interface Presenter {
        fun fetchPosts()
        fun onDestroy()
        
    }
}